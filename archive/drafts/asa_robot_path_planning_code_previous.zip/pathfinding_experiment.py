import math, random, time, heapq, csv, os
from itertools import permutations
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional
import matplotlib.pyplot as plt

Point = Tuple[float, float]
Cell = Tuple[int, int]

@dataclass
class Circle:
    x: float
    y: float
    r: float

@dataclass
class Rect:
    x1: float
    y1: float
    x2: float
    y2: float

@dataclass
class MapScenario:
    name: str
    width: int
    height: int
    circles: List[Circle]
    rects: List[Rect]
    start: Cell
    goal: Cell


def is_free_point(s: MapScenario, p: Point, margin: float = 0.0) -> bool:
    x, y = p
    if x < 0 or y < 0 or x >= s.width or y >= s.height:
        return False
    for c in s.circles:
        if (x-c.x)**2 + (y-c.y)**2 <= (c.r+margin)**2:
            return False
    for r in s.rects:
        if (r.x1-margin) <= x <= (r.x2+margin) and (r.y1-margin) <= y <= (r.y2+margin):
            return False
    return True


def is_free_cell(s: MapScenario, cell: Cell) -> bool:
    x, y = cell
    return is_free_point(s, (x+0.5, y+0.5), margin=0.0)


def line_free(s: MapScenario, a: Point, b: Point, step: float = 1.0) -> bool:
    dist = math.dist(a, b)
    n = max(1, int(dist / step))
    for i in range(n + 1):
        t = i / n
        x = a[0] + (b[0] - a[0]) * t
        y = a[1] + (b[1] - a[1]) * t
        if not is_free_point(s, (x, y)):
            return False
    return True


def neighbors8(s: MapScenario, cell: Cell):
    x, y = cell
    for dx, dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
        nb = (x+dx, y+dy)
        if 0 <= nb[0] < s.width and 0 <= nb[1] < s.height and is_free_cell(s, nb):
            # avoid diagonal corner cutting by checking line center-to-center
            if line_free(s, (x+0.5,y+0.5), (nb[0]+0.5,nb[1]+0.5), 0.5):
                yield nb, math.sqrt(dx*dx + dy*dy)


def reconstruct(parent: Dict[Cell, Cell], start: Cell, goal: Cell) -> List[Cell]:
    if goal not in parent and goal != start:
        return []
    cur = goal
    path = [cur]
    while cur != start:
        cur = parent[cur]
        path.append(cur)
    path.reverse()
    return path


def path_cost_cells(path: List[Cell]) -> float:
    if not path:
        return float('inf')
    return sum(math.dist(path[i], path[i+1]) for i in range(len(path)-1))


def path_cost_points(path: List[Point]) -> float:
    if not path:
        return float('inf')
    return sum(math.dist(path[i], path[i+1]) for i in range(len(path)-1))


def cell_center(cell: Cell) -> Point:
    return (cell[0] + 0.5, cell[1] + 0.5)


def brute_force_waypoints(s: MapScenario, max_waypoints=3, max_candidates=24):
    start = cell_center(s.start)
    goal = cell_center(s.goal)
    raw_candidates: List[Point] = []
    priority_raw_candidates: List[Point] = []

    # Candidate points are sampled around obstacle boundaries and along the
    # start-goal corridor, then every short waypoint sequence is enumerated.
    for x in [10, 18, 24, 30, 36, 42, 50]:
        for y in [5, 10, 15, 20, 25, 30, 35]:
            raw_candidates.append((x + 0.5, y + 0.5))
    for r in s.rects:
        pad = 2.5
        for x in [r.x1 - pad, r.x2 + pad]:
            for y in [r.y1 - pad, r.y2 + pad]:
                priority_raw_candidates.append((x, y))
        priority_raw_candidates.extend([
            ((r.x1 + r.x2) / 2, r.y1 - pad),
            ((r.x1 + r.x2) / 2, r.y2 + pad),
            (r.x1 - pad, (r.y1 + r.y2) / 2),
            (r.x2 + pad, (r.y1 + r.y2) / 2),
        ])
    for c in s.circles:
        radius = c.r + 2.4
        for k in range(8):
            angle = math.tau * k / 8
            raw_candidates.append((c.x + radius * math.cos(angle), c.y + radius * math.sin(angle)))

    def clean_candidates(points: List[Point], seen):
        cleaned = []
        for p in points:
            key = (round(p[0], 1), round(p[1], 1))
            if key in seen or not is_free_point(s, p):
                continue
            seen.add(key)
            cleaned.append(p)
        return cleaned

    seen = set()
    priority_candidates = clean_candidates(priority_raw_candidates, seen)
    candidates = clean_candidates(raw_candidates, seen)

    sx, sy = start
    gx, gy = goal
    line_len = max(1e-9, math.dist(start, goal))

    def corridor_score(p: Point) -> float:
        px, py = p
        det = abs((gx - sx) * (sy - py) - (sx - px) * (gy - sy))
        perpendicular = det / line_len
        return math.dist(start, p) + math.dist(p, goal) + 0.35 * perpendicular

    priority_candidates.sort(key=corridor_score)
    candidates.sort(key=corridor_score)
    candidates = priority_candidates[:10] + candidates[:max(0, max_candidates - len(priority_candidates[:10]))]

    visibility_cache = {}

    def segment_free(a: Point, b: Point) -> bool:
        key = tuple(sorted(((round(a[0], 2), round(a[1], 2)), (round(b[0], 2), round(b[1], 2)))))
        if key not in visibility_cache:
            visibility_cache[key] = line_free(s, a, b, step=0.75)
        return visibility_cache[key]

    best_path: List[Point] = []
    best_cost = float('inf')
    checked = 1
    if segment_free(start, goal):
        best_path = [start, goal]
        best_cost = math.dist(start, goal)

    for depth in range(1, max_waypoints + 1):
        for seq in permutations(candidates, depth):
            checked += 1
            route = [start, *seq, goal]
            cost = 0.0
            feasible = True
            for a, b in zip(route, route[1:]):
                cost += math.dist(a, b)
                if cost >= best_cost or not segment_free(a, b):
                    feasible = False
                    break
            if feasible and cost < best_cost:
                best_path = route
                best_cost = cost

    return best_path, best_cost, checked, bool(best_path)


def ucs(s: MapScenario):
    start, goal = s.start, s.goal
    pq = [(0.0, start)]
    dist = {start: 0.0}
    parent = {}
    expanded = 0
    visited = set()
    while pq:
        g, u = heapq.heappop(pq)
        if u in visited:
            continue
        visited.add(u)
        expanded += 1
        if u == goal:
            break
        for v, c in neighbors8(s, u):
            ng = g + c
            if ng < dist.get(v, float('inf')):
                dist[v] = ng
                parent[v] = u
                heapq.heappush(pq, (ng, v))
    path = reconstruct(parent, start, goal) if goal in dist else []
    return path, path_cost_cells(path), expanded, bool(path)


def astar(s: MapScenario):
    start, goal = s.start, s.goal
    def h(c): return math.dist(c, goal)
    pq = [(h(start), 0.0, start)]
    dist = {start: 0.0}
    parent = {}
    expanded = 0
    visited = set()
    while pq:
        f, g, u = heapq.heappop(pq)
        if u in visited:
            continue
        visited.add(u)
        expanded += 1
        if u == goal:
            break
        for v, c in neighbors8(s, u):
            ng = g + c
            if ng < dist.get(v, float('inf')):
                dist[v] = ng
                parent[v] = u
                heapq.heappush(pq, (ng + h(v), ng, v))
    path = reconstruct(parent, start, goal) if goal in dist else []
    return path, path_cost_cells(path), expanded, bool(path)


def gbfs(s: MapScenario):
    start, goal = s.start, s.goal
    def h(c): return math.dist(c, goal)
    pq = [(h(start), 0.0, start)]
    dist = {start: 0.0}
    parent = {}
    expanded = 0
    visited = set()
    while pq:
        _, g, u = heapq.heappop(pq)
        if u in visited:
            continue
        visited.add(u)
        expanded += 1
        if u == goal:
            break
        for v, c in neighbors8(s, u):
            if v in visited:
                continue
            ng = g + c
            if ng < dist.get(v, float('inf')):
                dist[v] = ng
                parent[v] = u
                heapq.heappush(pq, (h(v), ng, v))
    path = reconstruct(parent, start, goal) if goal in dist else []
    return path, path_cost_cells(path), expanded, bool(path)


def rrt_star(s: MapScenario, seed: int, max_iter=1200, step_size=2.5, radius=5.0, goal_sample_rate=0.12):
    rnd = random.Random(seed)
    start = (s.start[0] + 0.5, s.start[1] + 0.5)
    goal = (s.goal[0] + 0.5, s.goal[1] + 0.5)
    nodes = [start]
    parent = [-1]
    cost = [0.0]
    goal_idx: Optional[int] = None

    def sample():
        if rnd.random() < goal_sample_rate:
            return goal
        return (rnd.uniform(0, s.width-1e-3), rnd.uniform(0, s.height-1e-3))

    def nearest(p):
        return min(range(len(nodes)), key=lambda i: math.dist(nodes[i], p))

    def steer(a, b):
        d = math.dist(a, b)
        if d <= step_size:
            return b
        return (a[0] + (b[0]-a[0]) * step_size / d, a[1] + (b[1]-a[1]) * step_size / d)

    for _ in range(max_iter):
        p_rand = sample()
        i_near = nearest(p_rand)
        p_new = steer(nodes[i_near], p_rand)
        if not is_free_point(s, p_new) or not line_free(s, nodes[i_near], p_new):
            continue
        near_idxs = [i for i, p in enumerate(nodes) if math.dist(p, p_new) <= radius and line_free(s, p, p_new)]
        best_parent = i_near
        best_cost = cost[i_near] + math.dist(nodes[i_near], p_new)
        for i in near_idxs:
            c = cost[i] + math.dist(nodes[i], p_new)
            if c < best_cost:
                best_parent = i
                best_cost = c
        nodes.append(p_new)
        parent.append(best_parent)
        cost.append(best_cost)
        new_idx = len(nodes) - 1
        # Rewire
        for i in near_idxs:
            new_cost = best_cost + math.dist(p_new, nodes[i])
            if new_cost < cost[i] and line_free(s, p_new, nodes[i]):
                parent[i] = new_idx
                cost[i] = new_cost
        if math.dist(p_new, goal) <= step_size and line_free(s, p_new, goal):
            # Add actual goal node, but keep improving until iterations end.
            g_cost = best_cost + math.dist(p_new, goal)
            if goal_idx is None:
                nodes.append(goal)
                parent.append(new_idx)
                cost.append(g_cost)
                goal_idx = len(nodes) - 1
            elif g_cost < cost[goal_idx]:
                parent[goal_idx] = new_idx
                cost[goal_idx] = g_cost
    if goal_idx is None:
        return [], float('inf'), len(nodes), False, nodes, parent
    # reconstruct
    idx = goal_idx
    path = []
    while idx != -1:
        path.append(nodes[idx])
        idx = parent[idx]
    path.reverse()
    return path, cost[goal_idx], len(nodes), True, nodes, parent


def scenario_from_seed(kind: str, seed: int) -> MapScenario:
    rnd = random.Random(seed)
    width, height = 60, 40
    start, goal = (3, 20), (56, 20)
    circles=[]; rects=[]
    if kind == 'Mudah':
        for _ in range(5):
            circles.append(Circle(rnd.uniform(15,45), rnd.uniform(8,32), rnd.uniform(2.0,3.5)))
    elif kind == 'Sedang':
        for _ in range(10):
            circles.append(Circle(rnd.uniform(12,48), rnd.uniform(5,35), rnd.uniform(2.0,3.8)))
        rects.append(Rect(29,0,31,12)); rects.append(Rect(29,28,31,40))
    elif kind == 'Sulit':
        rects.extend([Rect(18,0,21,26), Rect(36,14,39,40)])
        for _ in range(8):
            circles.append(Circle(rnd.uniform(12,48), rnd.uniform(6,34), rnd.uniform(2.0,3.0)))
    elif kind == 'Padat':
        for _ in range(19):
            circles.append(Circle(rnd.uniform(9,51), rnd.uniform(4,36), rnd.uniform(1.8,3.5)))
        rects.extend([Rect(25,0,27,15), Rect(35,25,37,40)])
    s=MapScenario(kind,width,height,circles,rects,start,goal)
    # ensure start/goal free by removing obstacle too close
    s.circles = [c for c in s.circles if math.dist((c.x,c.y),(start[0]+0.5,start[1]+0.5))>c.r+4 and math.dist((c.x,c.y),(goal[0]+0.5,goal[1]+0.5))>c.r+4]
    return s


def run_experiment(outdir=None):
    if outdir is None:
        outdir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(outdir, exist_ok=True)
    kinds = ['Mudah','Sedang','Sulit','Padat']
    grid_algorithms = [('UCS', ucs), ('GBFS', gbfs), ('A*', astar)]
    algorithm_order = ['Brute Force', 'UCS', 'GBFS', 'A*', 'RRT*']
    rows=[]
    detail_paths={}
    for kind in kinds:
        for seed in range(5):
            s=scenario_from_seed(kind, 1000*len(kind)+seed)
            t0=time.perf_counter()
            path,cost,expanded,success=brute_force_waypoints(s)
            ms=(time.perf_counter()-t0)*1000
            rows.append(dict(scenario=kind, seed=seed, algorithm='Brute Force', success=int(success), cost=cost if success else '', time_ms=ms, expanded=expanded))
            if kind=='Sulit' and seed==4:
                detail_paths['Brute Force']=(path, s)
            for name, func in grid_algorithms:
                t0=time.perf_counter()
                path,cost,expanded,success=func(s)
                ms=(time.perf_counter()-t0)*1000
                rows.append(dict(scenario=kind, seed=seed, algorithm=name, success=int(success), cost=cost if success else '', time_ms=ms, expanded=expanded))
                if kind=='Sulit' and seed==4:
                    detail_paths[name]=(path, s)
            t0=time.perf_counter()
            path,cost,expanded,success,nodes,parent=rrt_star(s, seed=5000+seed+len(kind)*100, max_iter=650 if kind!='Padat' else 950, radius=4.5)
            ms=(time.perf_counter()-t0)*1000
            rows.append(dict(scenario=kind, seed=seed, algorithm='RRT*', success=int(success), cost=cost if success else '', time_ms=ms, expanded=expanded))
            if kind=='Sulit' and seed==4:
                detail_paths['RRT*']=(path, s)
    csv_path=os.path.join(outdir,'hasil_eksperimen.csv')
    with open(csv_path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['scenario','seed','algorithm','success','cost','time_ms','expanded'])
        w.writeheader(); w.writerows(rows)
    # Aggregate
    import statistics
    agg=[]
    for kind in kinds:
        for alg in algorithm_order:
            subset=[r for r in rows if r['scenario']==kind and r['algorithm']==alg]
            success_rate=sum(r['success'] for r in subset)/len(subset)*100
            success_cost=[float(r['cost']) for r in subset if r['success']]
            times=[float(r['time_ms']) for r in subset]
            expanded=[int(r['expanded']) for r in subset]
            agg.append({
                'scenario':kind,
                'algorithm':alg,
                'success_rate':success_rate,
                'avg_cost':statistics.mean(success_cost) if success_cost else float('nan'),
                'avg_time_ms':statistics.mean(times),
                'avg_expanded':statistics.mean(expanded),
            })
    agg_path=os.path.join(outdir,'ringkasan_eksperimen.csv')
    with open(agg_path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(agg[0].keys()))
        w.writeheader(); w.writerows(agg)
    # create figure for scenario hard seed 2
    fig_path=os.path.join(outdir,'fig_perbandingan_jalur.png')
    s = detail_paths['UCS'][1]
    plt.figure(figsize=(6.4,3.8), dpi=220)
    ax=plt.gca()
    ax.set_xlim(0,s.width); ax.set_ylim(0,s.height); ax.set_aspect('equal')
    ax.set_title('Perbandingan jalur pada skenario sulit', fontsize=9)
    for c in s.circles:
        ax.add_patch(plt.Circle((c.x,c.y),c.r, fill=True, alpha=0.25))
    for r in s.rects:
        ax.add_patch(plt.Rectangle((r.x1,r.y1),r.x2-r.x1,r.y2-r.y1, fill=True, alpha=0.25))
    alg_styles={'Brute Force':'-','UCS':'--','GBFS':'-.','A*':':','RRT*':'-'}
    for alg,(path,_) in detail_paths.items():
        if not path: continue
        if alg in ('UCS','GBFS','A*'):
            xs=[p[0]+0.5 for p in path]; ys=[p[1]+0.5 for p in path]
        else:
            xs=[p[0] for p in path]; ys=[p[1] for p in path]
        ax.plot(xs,ys,alg_styles[alg], linewidth=1.4, label=alg)
    ax.scatter([s.start[0]+0.5],[s.start[1]+0.5], marker='o', s=18, label='Start')
    ax.scatter([s.goal[0]+0.5],[s.goal[1]+0.5], marker='x', s=28, label='Goal')
    ax.grid(True, linewidth=0.25, alpha=0.35)
    ax.legend(fontsize=7, loc='upper right')
    plt.tight_layout()
    plt.savefig(fig_path, bbox_inches='tight')
    plt.close()
    # bar chart average time
    time_fig=os.path.join(outdir,'fig_waktu_rata_rata.png')
    plt.figure(figsize=(6.2,3.8), dpi=220)
    x=list(range(len(kinds)))
    widthb=0.16
    for j,alg in enumerate(algorithm_order):
        vals=[next(a for a in agg if a['scenario']==k and a['algorithm']==alg)['avg_time_ms'] for k in kinds]
        offset = (j - (len(algorithm_order)-1)/2) * widthb
        plt.bar([i+offset for i in x], vals, width=widthb, label=alg)
    plt.xticks(x,kinds)
    plt.ylabel('Waktu rata-rata (ms)')
    plt.title('Waktu eksekusi rata-rata per skenario', fontsize=9)
    plt.legend(fontsize=6, ncols=2)
    plt.tight_layout()
    plt.savefig(time_fig,bbox_inches='tight')
    plt.close()
    return csv_path,agg_path,fig_path,time_fig,agg

if __name__ == '__main__':
    csv_path,agg_path,fig_path,time_fig,agg=run_experiment()
    print(csv_path)
    print(agg_path)
    for a in agg:
        print(a)
